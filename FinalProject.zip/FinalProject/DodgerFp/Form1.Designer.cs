﻿namespace DodgerFp
{
    partial class dodger
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(dodger));
            System.Windows.Forms.ListViewItem listViewItem1 = new System.Windows.Forms.ListViewItem(new string[] {
            "500"}, -1, System.Drawing.Color.Red, System.Drawing.SystemColors.InfoText, new System.Drawing.Font("Old English Text MT", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0))));
            System.Windows.Forms.ListViewItem listViewItem2 = new System.Windows.Forms.ListViewItem("");
            System.Windows.Forms.ListViewItem listViewItem3 = new System.Windows.Forms.ListViewItem("");
            System.Windows.Forms.ListViewItem listViewItem4 = new System.Windows.Forms.ListViewItem("");
            this.obsticleLeft = new System.Windows.Forms.PictureBox();
            this.obsticleRight = new System.Windows.Forms.PictureBox();
            this.player = new System.Windows.Forms.PictureBox();
            this.life = new System.Windows.Forms.PictureBox();
            this.coin = new System.Windows.Forms.PictureBox();
            this.startGame = new System.Windows.Forms.Button();
            this.scoreBoard = new System.Windows.Forms.Button();
            this.rulesbtn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.lives = new System.Windows.Forms.Label();
            this.moveIn = new System.Windows.Forms.Label();
            this.coins = new System.Windows.Forms.Label();
            this.lifeCounter = new System.Windows.Forms.Label();
            this.timeToMoveCounter = new System.Windows.Forms.Label();
            this.coinsCounter = new System.Windows.Forms.Label();
            this.scoreCounter = new System.Windows.Forms.Label();
            this.theVoid = new System.Windows.Forms.Label();
            this.youDied = new System.Windows.Forms.PictureBox();
            this.obsticleLeft2 = new System.Windows.Forms.PictureBox();
            this.obsticleRight2 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.titleCard = new System.Windows.Forms.Label();
            this.CountDownToMoveTimer = new System.Windows.Forms.Timer(this.components);
            this.homeScreen = new System.Windows.Forms.Button();
            this.scoreSheet = new System.Windows.Forms.ListView();
            this.scoreLabel = new System.Windows.Forms.Label();
            this.rulesText = new System.Windows.Forms.RichTextBox();
            this.rulesLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.obsticleLeft)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.obsticleRight)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.player)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.life)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.coin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.youDied)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.obsticleLeft2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.obsticleRight2)).BeginInit();
            this.SuspendLayout();
            // 
            // obsticleLeft
            // 
            this.obsticleLeft.Image = ((System.Drawing.Image)(resources.GetObject("obsticleLeft.Image")));
            this.obsticleLeft.Location = new System.Drawing.Point(900, 50);
            this.obsticleLeft.Name = "obsticleLeft";
            this.obsticleLeft.Size = new System.Drawing.Size(250, 50);
            this.obsticleLeft.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.obsticleLeft.TabIndex = 0;
            this.obsticleLeft.TabStop = false;
            // 
            // obsticleRight
            // 
            this.obsticleRight.Image = ((System.Drawing.Image)(resources.GetObject("obsticleRight.Image")));
            this.obsticleRight.Location = new System.Drawing.Point(900, 50);
            this.obsticleRight.Name = "obsticleRight";
            this.obsticleRight.Size = new System.Drawing.Size(550, 50);
            this.obsticleRight.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.obsticleRight.TabIndex = 1;
            this.obsticleRight.TabStop = false;
            // 
            // player
            // 
            this.player.Image = ((System.Drawing.Image)(resources.GetObject("player.Image")));
            this.player.Location = new System.Drawing.Point(-100, -500);
            this.player.Name = "player";
            this.player.Size = new System.Drawing.Size(50, 50);
            this.player.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.player.TabIndex = 2;
            this.player.TabStop = false;
            // 
            // life
            // 
            this.life.Image = ((System.Drawing.Image)(resources.GetObject("life.Image")));
            this.life.Location = new System.Drawing.Point(97, 173);
            this.life.Name = "life";
            this.life.Size = new System.Drawing.Size(25, 25);
            this.life.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.life.TabIndex = 3;
            this.life.TabStop = false;
            // 
            // coin
            // 
            this.coin.Image = ((System.Drawing.Image)(resources.GetObject("coin.Image")));
            this.coin.Location = new System.Drawing.Point(450, 349);
            this.coin.Name = "coin";
            this.coin.Size = new System.Drawing.Size(25, 25);
            this.coin.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.coin.TabIndex = 4;
            this.coin.TabStop = false;
            // 
            // startGame
            // 
            this.startGame.Font = new System.Drawing.Font("Modern No. 20", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.startGame.Location = new System.Drawing.Point(57, 241);
            this.startGame.Name = "startGame";
            this.startGame.Size = new System.Drawing.Size(95, 42);
            this.startGame.TabIndex = 5;
            this.startGame.Text = "Start";
            this.startGame.UseVisualStyleBackColor = true;
            this.startGame.Click += new System.EventHandler(this.startGame_Click);
            // 
            // scoreBoard
            // 
            this.scoreBoard.Font = new System.Drawing.Font("Modern No. 20", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.scoreBoard.Location = new System.Drawing.Point(208, 241);
            this.scoreBoard.Name = "scoreBoard";
            this.scoreBoard.Size = new System.Drawing.Size(156, 42);
            this.scoreBoard.TabIndex = 5;
            this.scoreBoard.Text = "High Scores";
            this.scoreBoard.UseVisualStyleBackColor = true;
            this.scoreBoard.Click += new System.EventHandler(this.scoreBoard_Click);
            // 
            // rulesbtn
            // 
            this.rulesbtn.Font = new System.Drawing.Font("Modern No. 20", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rulesbtn.Location = new System.Drawing.Point(421, 241);
            this.rulesbtn.Name = "rulesbtn";
            this.rulesbtn.Size = new System.Drawing.Size(113, 42);
            this.rulesbtn.TabIndex = 5;
            this.rulesbtn.Text = "Rules";
            this.rulesbtn.UseVisualStyleBackColor = true;
            this.rulesbtn.Click += new System.EventHandler(this.rulesbtn_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Old English Text MT", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(468, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 23);
            this.label1.TabIndex = 6;
            this.label1.Text = "Score:";
            // 
            // lives
            // 
            this.lives.AutoSize = true;
            this.lives.Font = new System.Drawing.Font("Old English Text MT", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lives.ForeColor = System.Drawing.Color.Red;
            this.lives.Location = new System.Drawing.Point(8, 10);
            this.lives.Name = "lives";
            this.lives.Size = new System.Drawing.Size(48, 23);
            this.lives.TabIndex = 7;
            this.lives.Text = "lives:";
            // 
            // moveIn
            // 
            this.moveIn.AutoSize = true;
            this.moveIn.Font = new System.Drawing.Font("Old English Text MT", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.moveIn.ForeColor = System.Drawing.Color.Red;
            this.moveIn.Location = new System.Drawing.Point(162, 10);
            this.moveIn.Name = "moveIn";
            this.moveIn.Size = new System.Drawing.Size(76, 23);
            this.moveIn.TabIndex = 8;
            this.moveIn.Text = "Move in:";
            // 
            // coins
            // 
            this.coins.AutoSize = true;
            this.coins.Font = new System.Drawing.Font("Old English Text MT", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.coins.ForeColor = System.Drawing.Color.Yellow;
            this.coins.Location = new System.Drawing.Point(329, 10);
            this.coins.Name = "coins";
            this.coins.Size = new System.Drawing.Size(70, 23);
            this.coins.TabIndex = 9;
            this.coins.Text = "Credits:";
            // 
            // lifeCounter
            // 
            this.lifeCounter.AutoSize = true;
            this.lifeCounter.Font = new System.Drawing.Font("Old English Text MT", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lifeCounter.ForeColor = System.Drawing.Color.Red;
            this.lifeCounter.Location = new System.Drawing.Point(53, 10);
            this.lifeCounter.Name = "lifeCounter";
            this.lifeCounter.Size = new System.Drawing.Size(20, 23);
            this.lifeCounter.TabIndex = 10;
            this.lifeCounter.Text = "3";
            // 
            // timeToMoveCounter
            // 
            this.timeToMoveCounter.AutoSize = true;
            this.timeToMoveCounter.Font = new System.Drawing.Font("Old English Text MT", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.timeToMoveCounter.ForeColor = System.Drawing.Color.Red;
            this.timeToMoveCounter.Location = new System.Drawing.Point(234, 10);
            this.timeToMoveCounter.Name = "timeToMoveCounter";
            this.timeToMoveCounter.Size = new System.Drawing.Size(30, 23);
            this.timeToMoveCounter.TabIndex = 11;
            this.timeToMoveCounter.Text = "10";
            // 
            // coinsCounter
            // 
            this.coinsCounter.AutoSize = true;
            this.coinsCounter.Font = new System.Drawing.Font("Old English Text MT", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.coinsCounter.ForeColor = System.Drawing.Color.Yellow;
            this.coinsCounter.Location = new System.Drawing.Point(395, 10);
            this.coinsCounter.Name = "coinsCounter";
            this.coinsCounter.Size = new System.Drawing.Size(20, 23);
            this.coinsCounter.TabIndex = 12;
            this.coinsCounter.Text = "0";
            // 
            // scoreCounter
            // 
            this.scoreCounter.AutoSize = true;
            this.scoreCounter.Font = new System.Drawing.Font("Old English Text MT", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.scoreCounter.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.scoreCounter.Location = new System.Drawing.Point(534, 10);
            this.scoreCounter.Name = "scoreCounter";
            this.scoreCounter.Size = new System.Drawing.Size(20, 23);
            this.scoreCounter.TabIndex = 13;
            this.scoreCounter.Text = "0";
            // 
            // theVoid
            // 
            this.theVoid.AutoSize = true;
            this.theVoid.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.theVoid.Location = new System.Drawing.Point(-900, -30);
            this.theVoid.Name = "theVoid";
            this.theVoid.Size = new System.Drawing.Size(49, 13);
            this.theVoid.TabIndex = 14;
            this.theVoid.Text = "The void";
            // 
            // youDied
            // 
            this.youDied.BackColor = System.Drawing.Color.Red;
            this.youDied.Image = ((System.Drawing.Image)(resources.GetObject("youDied.Image")));
            this.youDied.Location = new System.Drawing.Point(-600, -600);
            this.youDied.Name = "youDied";
            this.youDied.Size = new System.Drawing.Size(139, 50);
            this.youDied.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.youDied.TabIndex = 15;
            this.youDied.TabStop = false;
            // 
            // obsticleLeft2
            // 
            this.obsticleLeft2.Image = ((System.Drawing.Image)(resources.GetObject("obsticleLeft2.Image")));
            this.obsticleLeft2.Location = new System.Drawing.Point(-600, 0);
            this.obsticleLeft2.Name = "obsticleLeft2";
            this.obsticleLeft2.Size = new System.Drawing.Size(250, 50);
            this.obsticleLeft2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.obsticleLeft2.TabIndex = 0;
            this.obsticleLeft2.TabStop = false;
            // 
            // obsticleRight2
            // 
            this.obsticleRight2.Image = ((System.Drawing.Image)(resources.GetObject("obsticleRight2.Image")));
            this.obsticleRight2.Location = new System.Drawing.Point(-600, 0);
            this.obsticleRight2.Name = "obsticleRight2";
            this.obsticleRight2.Size = new System.Drawing.Size(550, 50);
            this.obsticleRight2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.obsticleRight2.TabIndex = 1;
            this.obsticleRight2.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(248, 101);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 16;
            this.label2.Text = "label2";
            // 
            // titleCard
            // 
            this.titleCard.AutoSize = true;
            this.titleCard.Font = new System.Drawing.Font("Old English Text MT", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.titleCard.ForeColor = System.Drawing.Color.Red;
            this.titleCard.Location = new System.Drawing.Point(102, 80);
            this.titleCard.Name = "titleCard";
            this.titleCard.Size = new System.Drawing.Size(388, 77);
            this.titleCard.TabIndex = 17;
            this.titleCard.Text = "DODGER!!";
            // 
            // CountDownToMoveTimer
            // 
            this.CountDownToMoveTimer.Interval = 1000;
            this.CountDownToMoveTimer.Tick += new System.EventHandler(this.Timer_Tick);
            // 
            // homeScreen
            // 
            this.homeScreen.Location = new System.Drawing.Point(251, 526);
            this.homeScreen.Name = "homeScreen";
            this.homeScreen.Size = new System.Drawing.Size(75, 23);
            this.homeScreen.TabIndex = 18;
            this.homeScreen.Text = "Home";
            this.homeScreen.UseVisualStyleBackColor = true;
            this.homeScreen.Click += new System.EventHandler(this.homeScreen_Click);
            // 
            // scoreSheet
            // 
            this.scoreSheet.BackColor = System.Drawing.SystemColors.InfoText;
            this.scoreSheet.HideSelection = false;
            listViewItem1.StateImageIndex = 0;
            listViewItem2.StateImageIndex = 0;
            listViewItem3.StateImageIndex = 0;
            listViewItem4.StateImageIndex = 0;
            this.scoreSheet.Items.AddRange(new System.Windows.Forms.ListViewItem[] {
            listViewItem1,
            listViewItem2,
            listViewItem3,
            listViewItem4});
            this.scoreSheet.Location = new System.Drawing.Point(-800, -160);
            this.scoreSheet.Name = "scoreSheet";
            this.scoreSheet.Size = new System.Drawing.Size(121, 97);
            this.scoreSheet.TabIndex = 19;
            this.scoreSheet.UseCompatibleStateImageBehavior = false;
            // 
            // scoreLabel
            // 
            this.scoreLabel.AutoSize = true;
            this.scoreLabel.Font = new System.Drawing.Font("Old English Text MT", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.scoreLabel.ForeColor = System.Drawing.Color.Red;
            this.scoreLabel.Location = new System.Drawing.Point(-900, -132);
            this.scoreLabel.Name = "scoreLabel";
            this.scoreLabel.Size = new System.Drawing.Size(97, 34);
            this.scoreLabel.TabIndex = 20;
            this.scoreLabel.Text = "Scores";
            // 
            // rulesText
            // 
            this.rulesText.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.rulesText.Font = new System.Drawing.Font("Old English Text MT", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rulesText.ForeColor = System.Drawing.Color.Red;
            this.rulesText.Location = new System.Drawing.Point(-1000, 20);
            this.rulesText.Name = "rulesText";
            this.rulesText.ReadOnly = true;
            this.rulesText.Size = new System.Drawing.Size(407, 358);
            this.rulesText.TabIndex = 21;
            this.rulesText.Text = resources.GetString("rulesText.Text");
            // 
            // rulesLabel
            // 
            this.rulesLabel.AutoSize = true;
            this.rulesLabel.Font = new System.Drawing.Font("Old English Text MT", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rulesLabel.ForeColor = System.Drawing.Color.Red;
            this.rulesLabel.Location = new System.Drawing.Point(-1000, 64);
            this.rulesLabel.Name = "rulesLabel";
            this.rulesLabel.Size = new System.Drawing.Size(60, 26);
            this.rulesLabel.TabIndex = 22;
            this.rulesLabel.Text = "Rules";
            // 
            // dodger
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(584, 561);
            this.Controls.Add(this.rulesLabel);
            this.Controls.Add(this.rulesText);
            this.Controls.Add(this.scoreLabel);
            this.Controls.Add(this.scoreSheet);
            this.Controls.Add(this.homeScreen);
            this.Controls.Add(this.titleCard);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.youDied);
            this.Controls.Add(this.theVoid);
            this.Controls.Add(this.scoreCounter);
            this.Controls.Add(this.coinsCounter);
            this.Controls.Add(this.timeToMoveCounter);
            this.Controls.Add(this.lifeCounter);
            this.Controls.Add(this.coins);
            this.Controls.Add(this.moveIn);
            this.Controls.Add(this.lives);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.rulesbtn);
            this.Controls.Add(this.scoreBoard);
            this.Controls.Add(this.startGame);
            this.Controls.Add(this.coin);
            this.Controls.Add(this.life);
            this.Controls.Add(this.player);
            this.Controls.Add(this.obsticleRight2);
            this.Controls.Add(this.obsticleRight);
            this.Controls.Add(this.obsticleLeft2);
            this.Controls.Add(this.obsticleLeft);
            this.KeyPreview = true;
            this.Name = "dodger";
            this.Text = "DODGER";
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyPress);
            ((System.ComponentModel.ISupportInitialize)(this.obsticleLeft)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.obsticleRight)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.player)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.life)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.coin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.youDied)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.obsticleLeft2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.obsticleRight2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox obsticleLeft;
        private System.Windows.Forms.PictureBox obsticleRight;
        private System.Windows.Forms.PictureBox player;
        private System.Windows.Forms.PictureBox life;
        private System.Windows.Forms.PictureBox coin;
        private System.Windows.Forms.Button startGame;
        private System.Windows.Forms.Button scoreBoard;
        private System.Windows.Forms.Button rulesbtn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lives;
        private System.Windows.Forms.Label moveIn;
        private System.Windows.Forms.Label coins;
        private System.Windows.Forms.Label lifeCounter;
        private System.Windows.Forms.Label timeToMoveCounter;
        private System.Windows.Forms.Label coinsCounter;
        private System.Windows.Forms.Label scoreCounter;
        private System.Windows.Forms.Label theVoid;
        private System.Windows.Forms.PictureBox youDied;
        private System.Windows.Forms.PictureBox obsticleLeft2;
        private System.Windows.Forms.PictureBox obsticleRight2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label titleCard;
        private System.Windows.Forms.Timer CountDownToMoveTimer;
        private System.Windows.Forms.Button homeScreen;
        private System.Windows.Forms.ListView scoreSheet;
        private System.Windows.Forms.Label scoreLabel;
        private System.Windows.Forms.RichTextBox rulesText;
        private System.Windows.Forms.Label rulesLabel;
    }
}

