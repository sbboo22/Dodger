﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DodgerFp
{
    public partial class dodger : Form
    {
        public dodger()
        {
            InitializeComponent();
        }
        public int iteration;
        public void startGame_Click(object sender, EventArgs e)
        {
            Timer timer1 = new Timer();
            timer1.Interval = 1000;
            timer1.Enabled = true;
            timer1.Tick += Timer_Tick;

            
            titleCard.Location = theVoid.Location;
            startGame.Location = theVoid.Location;
            scoreBoard.Location = theVoid.Location;
            obsticleLeft2.Location = theVoid.Location;
            obsticleRight2.Location = theVoid.Location;
            obsticleLeft.Location = new Point(0, 50);
            obsticleLeft.Size = new Size(0, 50);
            obsticleRight.Location = new Point(obsticleLeft.Width + 50, obsticleLeft.Height);
            player.Location = new Point(250, 450);
            life.Location = theVoid.Location;
            coin.Location = theVoid.Location;
            rulesbtn.Location = theVoid.Location;
            rulesLabel.Location = theVoid.Location;
            rulesText.Location = theVoid.Location;

        }


       /* private void slideLeft_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 'a')
            {
                player.Location = new Point(5, 5);
            }
        }*/

        /* protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            return base.ProcessCmdKey(ref msg, keyData);
        }*/
         private void Form1_KeyPress(object sender, KeyEventArgs e)
         {
            turn(player.Location.X);
           
            int collisonDetection(int x)
            {
                int parsedStuff = Int32.Parse(scoreCounter.Text);
                int parsedLives = Int32.Parse(lifeCounter.Text);
                int parsedcoin = Int32.Parse(coinsCounter.Text);
                string lablecoins;
                string lableLives;
                string Labler;
                if (obsticleLeft.Location.Y == 450)
                {
                    if (player.Location == new Point(obsticleLeft.Size.Width, 450))
                        parsedStuff = parsedStuff + 50;
                    else
                        parsedLives = parsedLives - 1;
                }
                else if (obsticleLeft2.Location.Y == 450)
                {
                    if (player.Location == new Point(obsticleLeft2.Size.Width, 450))
                        parsedStuff = parsedStuff + 50;
                    else
                        parsedLives = parsedLives - 1;
                }

                if (player.Location == life.Location && parsedLives < 3)
                    parsedLives = parsedLives + 1; life.Location = theVoid.Location;
                if (player.Location == coin.Location)
                    parsedcoin = parsedcoin + 10; coin.Location = theVoid.Location;
                Labler = parsedStuff.ToString();
                lableLives = parsedLives.ToString();
                lablecoins = parsedcoin.ToString();
                coinsCounter.Text = lablecoins;
                scoreCounter.Text = Labler;
                lifeCounter.Text = lableLives;

                return 0;
            }
            int opsChoices(int opEdited)
            {
                Random random = new Random();
                int opPosSelection = random.Next(0, 12);

                switch (opPosSelection)
                {
                    case 1:
                        if (opEdited == 1)
                        {
                            obsticleLeft.Size = new Size(0, 50);
                            obsticleRight.Location = new Point(obsticleLeft.Width + 50, obsticleLeft.Location.Y);
                        }
                        if(opEdited == 2)
                        {
                            obsticleLeft2.Size = new Size(0, 50);
                            obsticleRight2.Location = new Point(obsticleLeft2.Width + 50, obsticleLeft2.Location.Y);
                        }
                        break;
                    case 2:
                        if (opEdited == 1)
                        {
                            obsticleLeft.Size = new Size(50, 50);
                            obsticleRight.Location = new Point(obsticleLeft.Width + 50, obsticleLeft.Location.Y);
                        }
                        if (opEdited == 2)
                        {
                            obsticleLeft2.Size = new Size(50, 50);
                            obsticleRight2.Location = new Point(obsticleLeft2.Width + 50, obsticleLeft2.Location.Y);
                        }
                        break;
                    case 3:
                        if (opEdited == 1)
                        {
                            obsticleLeft.Size = new Size(100, 50);
                            obsticleRight.Location = new Point(obsticleLeft.Width + 50, obsticleLeft.Location.Y);
                        }
                        if (opEdited == 2)
                        {
                            obsticleLeft2.Size = new Size(100, 50);
                            obsticleRight2.Location = new Point(obsticleLeft2.Width + 50, obsticleLeft2.Location.Y);
                        }
                        break;
                    case 4:
                        if (opEdited == 1)
                        {
                            obsticleLeft.Size = new Size(150, 50);
                            obsticleRight.Location = new Point(obsticleLeft.Width + 50, obsticleLeft.Location.Y);
                        }
                        if (opEdited == 2)
                        {
                            obsticleLeft2.Size = new Size(150, 50);
                            obsticleRight2.Location = new Point(obsticleLeft2.Width + 50, obsticleLeft2.Location.Y);
                        }
                        break;
                    case 5:
                        if (opEdited == 1)
                        {
                            obsticleLeft.Size = new Size(200, 50);
                            obsticleRight.Location = new Point(obsticleLeft.Width + 50, obsticleLeft.Location.Y);
                        }
                        if (opEdited == 2)
                        {
                            obsticleLeft2.Size = new Size(200, 50);
                            obsticleRight2.Location = new Point(obsticleLeft2.Width + 50, obsticleLeft2.Location.Y);
                        }
                        break;
                    case 6:
                        if (opEdited == 1)
                        {
                            obsticleLeft.Size = new Size(250, 50);
                            obsticleRight.Location = new Point(obsticleLeft.Width + 50, obsticleLeft.Location.Y);
                        }
                        if (opEdited == 2)
                        {
                            obsticleLeft2.Size = new Size(250, 50);
                            obsticleRight2.Location = new Point(obsticleLeft2.Width + 50, obsticleLeft2.Location.Y);
                        }
                        break;
                    case 7:
                        if (opEdited == 1)
                        {
                            obsticleLeft.Size = new Size(300, 50);
                            obsticleRight.Location = new Point(obsticleLeft.Width + 50, obsticleLeft.Location.Y);
                        }
                        if (opEdited == 2)
                        {
                            obsticleLeft2.Size = new Size(300, 50);
                            obsticleRight2.Location = new Point(obsticleLeft2.Width + 50, obsticleLeft2.Location.Y);
                        }
                        break;
                    case 8:
                        if (opEdited == 1)
                        {
                            obsticleLeft.Size = new Size(350, 50);
                            obsticleRight.Location = new Point(obsticleLeft.Width + 50, obsticleLeft.Location.Y);
                        }
                        if (opEdited == 2)
                        {
                            obsticleLeft2.Size = new Size(350, 50);
                            obsticleRight2.Location = new Point(obsticleLeft2.Width + 50, obsticleLeft2.Location.Y);
                        }
                        break;
                    case 9:
                        if (opEdited == 1)
                        {
                            obsticleLeft.Size = new Size(400, 50);
                            obsticleRight.Location = new Point(obsticleLeft.Width + 50, obsticleLeft.Location.Y);
                        }
                        if (opEdited == 2)
                        {
                            obsticleLeft2.Size = new Size(400, 50);
                            obsticleRight2.Location = new Point(obsticleLeft2.Width + 50, obsticleLeft2.Location.Y);
                        }
                        break;
                    case 10:
                        if (opEdited == 1)
                        {
                            obsticleLeft.Size = new Size(450, 50);
                            obsticleRight.Location = new Point(obsticleLeft.Width + 50, obsticleLeft.Location.Y);
                        }
                        if (opEdited == 2)
                        {
                            obsticleLeft2.Size = new Size(450, 50);
                            obsticleRight2.Location = new Point(obsticleLeft2.Width + 50, obsticleLeft2.Location.Y);
                        }
                        break;
                    case 11:
                        if (opEdited == 1)
                        {
                            obsticleLeft.Size = new Size(500, 50);
                            obsticleRight.Location = new Point(obsticleLeft.Width + 50, obsticleLeft.Location.Y);
                        }
                        if (opEdited == 2)
                        {
                            obsticleLeft2.Size = new Size(500, 50);
                            obsticleRight2.Location = new Point(obsticleLeft2.Width + 50, obsticleLeft2.Location.Y);
                        }
                        break;
                    case 12:
                        if (opEdited == 1)
                        {
                            obsticleLeft.Size = new Size(550, 50);
                            obsticleRight.Location = new Point(obsticleLeft.Width + 50, obsticleLeft.Location.Y);
                        }
                        if (opEdited == 2)
                        {
                            obsticleLeft2.Size = new Size(550, 50);
                            obsticleRight2.Location = new Point(obsticleLeft2.Width + 50, obsticleLeft2.Location.Y);
                        }
                        break;

                }

                 
            return 0;
            }
            void moveTheOps()
            {
                Random _random = new Random();
                Random _random2 = new Random();
                int itemPositon;
                int itemChance;
                bool itemOnBoard = false;
                obsticleLeft.Location = new Point(0, obsticleLeft.Location.Y + 50);
                obsticleRight.Location = new Point(obsticleLeft.Size.Width + 50, obsticleLeft.Location.Y);
                coin.Location = new Point(coin.Location.X, coin.Location.Y + 50);
                life.Location = new Point(life.Location.X, life.Location.Y + 50);
                if (obsticleLeft.Location.Y == 450)
                {
                    opsChoices(2);
                    obsticleLeft2.Location = new Point(0, 50);
                    itemPositon = _random.Next(0, 11);
                    itemChance = _random2.Next(1, 5);
                    if (itemChance == 2)
                    {
                        itemPositon = itemPositon * 50;
                        life.Location = new Point(itemPositon, 200);
                    }
                    if (itemChance == 4)
                    {
                        itemPositon = itemPositon * 50;
                        coin.Location = new Point(itemPositon, 200);
                    }
                }
                if (obsticleLeft2.Location.Y == 450)
                {
                    opsChoices(1);
                    obsticleLeft.Location = new Point(0, 50);
                    itemPositon = _random.Next(0, 11);
                    itemChance = _random2.Next(1, 5);
                    if (itemChance == 2)
                    {
                        itemPositon = itemPositon * 50;
                        life.Location = new Point(itemPositon, 200);
                    }
                    if (itemChance == 4)
                    {
                        itemPositon = itemPositon * 50;
                        coin.Location = new Point(itemPositon, 200);

                    }
                }
                obsticleLeft2.Location = new Point(0, obsticleLeft2.Location.Y + 50);
                obsticleRight2.Location = new Point(obsticleLeft2.Size.Width + 50, obsticleLeft2.Location.Y);
           
            }
            void youJustDied()
            {
                int i = 0;
                youDied.Location = new Point(20, 200);
                youDied.Size = new Size(550, 300);
                if (i < 5)
                    scoreSheet.Items.Add(scoreCounter.Text);

            }
            int turn(int x)
            {
                if (e.KeyCode == Keys.Left && x > 25) 
                {
                    player.Location = new Point(player.Location.X - 50, 450);
                    if (iteration > 25 && iteration <= 35)
                        timeToMoveCounter.Text = "5";
                    if (iteration > 35)
                        timeToMoveCounter.Text = "2";
                    else
                        timeToMoveCounter.Text = "10";
                    moveTheOps();
                    collisonDetection(obsticleLeft.Width);
                    iteration = iteration + 1;
                    if (lifeCounter.Text == "-1")
                        youJustDied();
                }
                if (e.KeyCode == Keys.Right && x < 575)
                {
                    player.Location = new Point(player.Location.X + 50, 450);
                    if (iteration > 25 && iteration <= 35)
                        timeToMoveCounter.Text = "5";
                    if (iteration > 35)
                        timeToMoveCounter.Text = "2";
                    else
                        timeToMoveCounter.Text = "10";
                    moveTheOps();
                    collisonDetection(1);
                    iteration = iteration + 1;
                    if (lifeCounter.Text == "-1")
                        youJustDied();
                }
                if (e.KeyCode == Keys.Space)
                {
                    InitializeComponent();
                }
                return 0;
            }
            
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            double timeholder;
            timeholder = Double.Parse(timeToMoveCounter.Text) * 1000;

            if (timeholder == 0)
            {
                
                iteration = iteration + 1;
                if (iteration > 25 && timeholder <= 35)
                {
                    timeholder = 0 + 5000;
                    if (player.Location.X >= 500)
                        player.Location = new Point(player.Location.X - 100, 450);
                        
                    else
                        player.Location = new Point(player.Location.X + 100, 450);
                    timeholder = 0 + 5000;
                }
                else if (iteration > 35)
                {
                    if (player.Location.X >= 500)
                        player.Location = new Point(player.Location.X - 100, 450);
                    else
                        player.Location = new Point(player.Location.X + 100, 450);
                    timeholder = 0 + 2000;
                }
                else
                {
                    if (player.Location.X >= 500)
                        player.Location = new Point(player.Location.X - 100, 450);
                    else
                        player.Location = new Point(player.Location.X + 100, 450);
                    timeholder = 0 + 10000;
                }

            }
            timeholder = (timeholder - 1000) / 1000;
            timeToMoveCounter.Text = timeholder.ToString();
        }

        private void homeScreen_Click(object sender, EventArgs e)
        {
            startGame.Location = new Point(57, 241);
            scoreBoard.Location = new Point(208, 241);
            rulesbtn.Location = new Point(421,241);
            titleCard.Location = new Point(101, 80);
            player.Location = theVoid.Location;
            obsticleLeft.Location = theVoid.Location;
            obsticleLeft2.Location = theVoid.Location;
            obsticleRight.Location = theVoid.Location;
            obsticleRight2.Location = theVoid.Location;
            youDied.Location = theVoid.Location;
            scoreLabel.Location = theVoid.Location;
            scoreSheet.Location = theVoid.Location;
            rulesLabel.Location = theVoid.Location;
            rulesText.Location = theVoid.Location;

        }

        private void scoreBoard_Click(object sender, EventArgs e)
        {
            life.Location = theVoid.Location;
            coin.Location = theVoid.Location;
            titleCard.Location = theVoid.Location;
            startGame.Location = theVoid.Location;
            scoreBoard.Location = theVoid.Location;
            obsticleLeft2.Location = theVoid.Location;
            obsticleRight2.Location = theVoid.Location;
            rulesbtn.Location = theVoid.Location;
            player.Location = theVoid.Location;
            scoreSheet.Location = new Point(222, 160);
            scoreLabel.Location = new Point(232, 132);
        }

        private void rulesbtn_Click(object sender, EventArgs e)
        {
            life.Location = theVoid.Location;
            coin.Location = theVoid.Location;
            titleCard.Location = theVoid.Location;
            startGame.Location = theVoid.Location;
            scoreBoard.Location = theVoid.Location;
            obsticleLeft2.Location = theVoid.Location;
            obsticleRight2.Location = theVoid.Location;
            rulesbtn.Location = theVoid.Location;
            player.Location = theVoid.Location;
            rulesLabel.Location = new Point(280, 64);
            rulesText.Location = new Point(97, 80);
        }
    }

    
}
